package U4ProgrammingA2;

public class Score { // This is the scoring system that will be used for the program.

    public void scoringSystem() {
    }
}
