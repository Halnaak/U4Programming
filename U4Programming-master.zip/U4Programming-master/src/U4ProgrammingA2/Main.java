package U4ProgrammingA2;

public class Main { // This is the main package which makes the code run as a program.

    private static int input;

    public static void main(String[] args) {
        Menu.eventType();
    }
}
