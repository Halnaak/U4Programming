package U4ProgrammingA2;

public class Tournament extends Event { // This is where the tournament is created and added onto the menu if a certain option is chosen.

    public static void createTournament() {
    }

    public static void tournamentResults() { // This is where the tournament results are.
    }
}
