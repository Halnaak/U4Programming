package U4ProgrammingA2;

public interface Actions { // This is the interface in which the methods are called upon.

    public void add(); //  Adds a player into a selected team, includes other variables such as FirstName and LastName aswell as the Team and adds them into the ArrayList.

    public void view(); // This shows a list of players in a team. If there is no players then it will prompt the user to enter players.

    public void remove(); // This clears a player's data.

    public void setFirstName(); // This sets the player's first name.

    public void setLastName(); // This sets the player's last name.

    public void setTeam(); // This sets the player's team.

    public void addToArrayList(); // This adds the team to the list of teams.
}
