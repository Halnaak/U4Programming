package U4ProgrammingA2;

import java.util.ArrayList;
import java.util.List;

public class ShortStore {

    protected static List<String> listPlayer = new ArrayList(); // This is a list of stored players.

    protected static List<String> listTeam = new ArrayList(); // This is a list of stored teams.
}
