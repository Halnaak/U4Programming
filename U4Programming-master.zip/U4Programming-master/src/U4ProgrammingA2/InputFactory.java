package U4ProgrammingA2;

import java.util.Scanner; // This imports a scanner.

public class InputFactory {

    protected static Scanner SC = new Scanner(System.in); 

    public static int checkInput(int iInput) { // This is the user input that is passed onto menu.
        return iInput;
    }
}
