package U4ProgrammingA2;

public class Event { // This declares the type of event.
    protected static int singleOrFiveEvents = 1; // These declare the type of event by changing the value of the variables, for example if the event is the first option then the value is 1, if it is the second option then the value is 2.

    protected static int individualOrTeam = 1; 

    protected static int sportingOrAcademic = 1; 

    public static void registerForEvent() { // These are used to check the value of the variable
    }

    public static int getEvents() {
        return singleOrFiveEvents; // These are used to check the value of the variable.
    }

    public static void individualOrTeam() {
    }

    public static void updateScore() {
    }
}
